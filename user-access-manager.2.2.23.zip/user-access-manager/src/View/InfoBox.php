<?php

?>
<div class="uam_info_box">
    <span class="uam_info_box--head"><?php echo TXT_UAM_INFO_BOX_UAM_PRO_HEAD; ?></span>
    <span class="uam_info_box--content"><?php echo TXT_UAM_INFO_BOX_UAM_PRO_CONTENT; ?></span>
    <a href="https://steadyhq.com/useraccessmanager?utm_source=publication&utm_medium=banner">
        <img alt="Support me on Steady"
             src="https://steady.imgix.net/gfx/banners/support_me_on_steady.png"
             style="width: 240px;"/>
    </a>
    <span class="uam_info_box--head"><?php echo TXT_UAM_INFO_BOX_DOCUMENTATION_HEAD; ?></span>
    <span class="uam_info_box--content"><?php echo TXT_UAM_INFO_BOX_DOCUMENTATION_CONTENT; ?></span>
</div>
