<?php
/**
 * @var LoginWidget $controller
 */

use UserAccessManager\Widget\LoginWidget;

?>
<section class="widget">
    <?php
    include 'Login/LoginForm.php';
    ?>
</section>