<?php

?>
<a href="https://steadyhq.com/useraccessmanager?utm_source=publication&utm_medium=banner">
    <img alt="Support me on Steady"
         src="https://steady.imgix.net/gfx/banners/support_me_on_steady.png"
         style="width: 240px;"/>
</a>
